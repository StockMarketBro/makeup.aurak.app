// api/stats.js — QUÉ AGREGAR a tu archivo actual
// No lo reemplaces entero: tu stats.js ya trae visitas totales, gráfico de
// 7 días y suscriptores de Brevo. Solo suma este bloque antes de responder,
// y añade las claves nuevas al objeto que ya devuelves.

// --- 1) Helper (si ya tienes uno equivalente, usa el tuyo) ---
async function redisGet(clave) {
  const r = await fetch(
    `${process.env.UPSTASH_REDIS_REST_URL}/GET/${clave}`,
    { headers: { Authorization: `Bearer ${process.env.UPSTASH_REDIS_REST_TOKEN}` } }
  );
  const j = await r.json();
  return parseInt(j.result || 0, 10);
}

function ultimosDias(n) {
  const dias = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(Date.now() - 5 * 3600 * 1000 - i * 86400 * 1000);
    dias.push(d.toISOString().slice(0, 10));
  }
  return dias;
}

// --- 2) Bloque a insertar dentro de tu handler, antes del res.status(200) ---
const dias = ultimosDias(7);

const [landingTotal, makeupTotal, aLanding, aMakeup] = await Promise.all([
  redisGet('visitas:landing:total'),
  redisGet('visitas:makeup:total'),
  redisGet('cruce:makeup->landing:total'),   // del Makeup Studio a la landing
  redisGet('cruce:aurak->makeup:total'),     // de la landing al Makeup Studio
]);

const serieLanding = await Promise.all(dias.map(d => redisGet(`visitas:landing:${d}`)));
const serieMakeup  = await Promise.all(dias.map(d => redisGet(`visitas:makeup:${d}`)));

// --- 3) Agrega estas claves al objeto que ya devuelves ---
// return res.status(200).json({
//   ...loQueYaDevuelves,
   apps: {
     landing: { total: landingTotal, serie: serieLanding },
     makeup:  { total: makeupTotal,  serie: serieMakeup  },
     dias,
   },
   cruce: {
     landingAMakeup: aMakeup,   // pasaron de aurak.app → Makeup Studio
     makeupALanding: aLanding,  // pasaron de Makeup Studio → aurak.app
     // % de visitantes del Makeup Studio que terminan en la landing
     tasaCruce: makeupTotal ? +(aLanding / makeupTotal * 100).toFixed(1) : 0,
   },
// });


/* ------------------------------------------------------------------
   PARA EL PANEL (admin.html): tarjetas nuevas a partir de esos datos

   <div class="cards">
     <div class="card"><h3>Landing</h3><p id="vLanding">–</p></div>
     <div class="card"><h3>Makeup Studio</h3><p id="vMakeup">–</p></div>
     <div class="card"><h3>Makeup → Landing</h3><p id="vCruce">–</p>
       <small id="vTasa"></small></div>
   </div>

   <script>
     // dentro de tu fetch de /api/stats:
     document.getElementById('vLanding').textContent = data.apps.landing.total;
     document.getElementById('vMakeup').textContent  = data.apps.makeup.total;
     document.getElementById('vCruce').textContent   = data.cruce.makeupALanding;
     document.getElementById('vTasa').textContent    = data.cruce.tasaCruce + '% de cruce';
   </script>
------------------------------------------------------------------ */
