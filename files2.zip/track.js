// api/track.js — contador de visitas de Aura-K
// Reemplaza tu track.js actual. Cambios respecto a la versión anterior:
//   1. Acepta peticiones desde makeup.aurak.app (CORS).
//   2. Separa las visitas por app: 'landing' y 'makeup'.
//   3. Registra el cruce entre apps (cuántos llegan de una a la otra).
// Las claves antiguas se mantienen intactas, así que tu historial no se pierde.

const REDIS_URL   = process.env.UPSTASH_REDIS_REST_URL;
const REDIS_TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN;

// Orígenes autorizados a reportar visitas.
// Ajusta si despliegas el Makeup Studio en otro subdominio.
const ORIGENES_OK = [
  'https://www.aurak.app',
  'https://aurak.app',
  'https://makeup.aurak.app',
];

async function redis(comando) {
  const r = await fetch(`${REDIS_URL}/${comando.join('/')}`, {
    headers: { Authorization: `Bearer ${REDIS_TOKEN}` },
  });
  return r.json();
}

function hoy() {
  // Fecha en horario de Lima, para que los días del panel cuadren
  return new Date(Date.now() - 5 * 3600 * 1000).toISOString().slice(0, 10);
}

export default async function handler(req, res) {
  // ---- CORS ----
  const origin = req.headers.origin;
  if (ORIGENES_OK.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  }
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    // src: 'landing' | 'makeup'   ·   from: 'aurak' | 'makeup' | 'directo'
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    const src  = body.src === 'makeup' ? 'makeup' : 'landing';
    const from = String(body.from || 'directo').slice(0, 20).replace(/[^a-z0-9_-]/gi, '');
    const dia  = hoy();

    const ops = [
      // Totales e histórico por día (claves originales: no se tocan)
      redis(['INCR', 'visitas:total']),
      redis(['INCR', `visitas:${dia}`]),
      // Nuevo: desglose por app
      redis(['INCR', `visitas:${src}:total`]),
      redis(['INCR', `visitas:${src}:${dia}`]),
    ];

    // Cruce entre apps: cuántos entran al Makeup Studio viniendo de la landing,
    // y viceversa. Este es el número que dice si el embudo funciona.
    if (from !== 'directo') {
      ops.push(redis(['INCR', `cruce:${from}->${src}:total`]));
      ops.push(redis(['INCR', `cruce:${from}->${src}:${dia}`]));
    }

    await Promise.all(ops);
    return res.status(200).json({ ok: true });
  } catch (e) {
    // El tracking nunca debe romper nada: si falla, se responde ok igual.
    return res.status(200).json({ ok: false });
  }
}
